﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.startButton1 = New System.Windows.Forms.Button()
        Me.txtStartCount0 = New System.Windows.Forms.TextBox()
        Me.txtEndCount0 = New System.Windows.Forms.TextBox()
        Me.txtIncrement0 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblIncrement = New System.Windows.Forms.Label()
        Me.txtTimeOn0 = New System.Windows.Forms.TextBox()
        Me.txtTimeOff0 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.SerialPort1 = New System.IO.Ports.SerialPort(Me.components)
        Me.txtComNumber1 = New System.Windows.Forms.TextBox()
        Me.testSerialPort1 = New System.Windows.Forms.Button()
        Me.lblComPort1 = New System.Windows.Forms.Label()
        Me.lblComPort2 = New System.Windows.Forms.Label()
        Me.testSerialPort2 = New System.Windows.Forms.Button()
        Me.txtComNumber2 = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtIncrement1 = New System.Windows.Forms.TextBox()
        Me.txtEndCount1 = New System.Windows.Forms.TextBox()
        Me.txtStartCount1 = New System.Windows.Forms.TextBox()
        Me.SerialPort2 = New System.IO.Ports.SerialPort(Me.components)
        Me.SerialPort3 = New System.IO.Ports.SerialPort(Me.components)
        Me.SerialPort4 = New System.IO.Ports.SerialPort(Me.components)
        Me.rdbSerial0_8 = New System.Windows.Forms.RadioButton()
        Me.rdbSerial0_16 = New System.Windows.Forms.RadioButton()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.lblValue1 = New System.Windows.Forms.Label()
        Me.lblValue0 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.rdbSerial1_16 = New System.Windows.Forms.RadioButton()
        Me.rdbSerial1_8 = New System.Windows.Forms.RadioButton()
        Me.btnCloseSave = New System.Windows.Forms.Button()
        Me.txtCyclePause = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.lblOn0 = New System.Windows.Forms.Label()
        Me.lblOff1 = New System.Windows.Forms.Label()
        Me.lblOff0 = New System.Windows.Forms.Label()
        Me.lblOn1 = New System.Windows.Forms.Label()
        Me.lblOffArrow1 = New System.Windows.Forms.Label()
        Me.lblOnArrow1 = New System.Windows.Forms.Label()
        Me.lblOffArrow0 = New System.Windows.Forms.Label()
        Me.lblOnArrow0 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'startButton1
        '
        Me.startButton1.Location = New System.Drawing.Point(439, 12)
        Me.startButton1.Name = "startButton1"
        Me.startButton1.Size = New System.Drawing.Size(75, 50)
        Me.startButton1.TabIndex = 17
        Me.startButton1.Text = "Start"
        Me.startButton1.UseVisualStyleBackColor = True
        '
        'txtStartCount0
        '
        Me.txtStartCount0.Location = New System.Drawing.Point(25, 114)
        Me.txtStartCount0.Name = "txtStartCount0"
        Me.txtStartCount0.Size = New System.Drawing.Size(100, 20)
        Me.txtStartCount0.TabIndex = 7
        Me.txtStartCount0.Text = "1"
        '
        'txtEndCount0
        '
        Me.txtEndCount0.Location = New System.Drawing.Point(25, 143)
        Me.txtEndCount0.Name = "txtEndCount0"
        Me.txtEndCount0.Size = New System.Drawing.Size(100, 20)
        Me.txtEndCount0.TabIndex = 8
        Me.txtEndCount0.Text = "10"
        '
        'txtIncrement0
        '
        Me.txtIncrement0.Location = New System.Drawing.Point(25, 172)
        Me.txtIncrement0.Name = "txtIncrement0"
        Me.txtIncrement0.Size = New System.Drawing.Size(100, 20)
        Me.txtIncrement0.TabIndex = 9
        Me.txtIncrement0.Text = "1"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(133, 119)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(29, 13)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Start"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(133, 148)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(29, 13)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Stop"
        '
        'lblIncrement
        '
        Me.lblIncrement.AutoSize = True
        Me.lblIncrement.Location = New System.Drawing.Point(133, 177)
        Me.lblIncrement.Name = "lblIncrement"
        Me.lblIncrement.Size = New System.Drawing.Size(54, 13)
        Me.lblIncrement.TabIndex = 6
        Me.lblIncrement.Text = "Increment"
        '
        'txtTimeOn0
        '
        Me.txtTimeOn0.Location = New System.Drawing.Point(25, 201)
        Me.txtTimeOn0.Name = "txtTimeOn0"
        Me.txtTimeOn0.Size = New System.Drawing.Size(100, 20)
        Me.txtTimeOn0.TabIndex = 10
        Me.txtTimeOn0.Text = "1000"
        '
        'txtTimeOff0
        '
        Me.txtTimeOff0.Location = New System.Drawing.Point(25, 230)
        Me.txtTimeOff0.Name = "txtTimeOff0"
        Me.txtTimeOff0.Size = New System.Drawing.Size(100, 20)
        Me.txtTimeOff0.TabIndex = 11
        Me.txtTimeOff0.Text = "0"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(133, 206)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(51, 13)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "On Value"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(133, 235)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(51, 13)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Off Value"
        '
        'txtComNumber1
        '
        Me.txtComNumber1.Location = New System.Drawing.Point(36, 3)
        Me.txtComNumber1.Name = "txtComNumber1"
        Me.txtComNumber1.Size = New System.Drawing.Size(21, 20)
        Me.txtComNumber1.TabIndex = 1
        Me.txtComNumber1.Text = "0"
        '
        'testSerialPort1
        '
        Me.testSerialPort1.Location = New System.Drawing.Point(63, 1)
        Me.testSerialPort1.Name = "testSerialPort1"
        Me.testSerialPort1.Size = New System.Drawing.Size(49, 23)
        Me.testSerialPort1.TabIndex = 2
        Me.testSerialPort1.Text = "Test"
        Me.testSerialPort1.UseVisualStyleBackColor = True
        '
        'lblComPort1
        '
        Me.lblComPort1.AutoSize = True
        Me.lblComPort1.Location = New System.Drawing.Point(4, 3)
        Me.lblComPort1.Name = "lblComPort1"
        Me.lblComPort1.Size = New System.Drawing.Size(31, 13)
        Me.lblComPort1.TabIndex = 18
        Me.lblComPort1.Text = "COM"
        '
        'lblComPort2
        '
        Me.lblComPort2.AutoSize = True
        Me.lblComPort2.Location = New System.Drawing.Point(192, 4)
        Me.lblComPort2.Name = "lblComPort2"
        Me.lblComPort2.Size = New System.Drawing.Size(31, 13)
        Me.lblComPort2.TabIndex = 35
        Me.lblComPort2.Text = "COM"
        '
        'testSerialPort2
        '
        Me.testSerialPort2.Location = New System.Drawing.Point(250, -1)
        Me.testSerialPort2.Name = "testSerialPort2"
        Me.testSerialPort2.Size = New System.Drawing.Size(49, 23)
        Me.testSerialPort2.TabIndex = 4
        Me.testSerialPort2.Text = "Test"
        Me.testSerialPort2.UseVisualStyleBackColor = True
        '
        'txtComNumber2
        '
        Me.txtComNumber2.Location = New System.Drawing.Point(223, 1)
        Me.txtComNumber2.Name = "txtComNumber2"
        Me.txtComNumber2.Size = New System.Drawing.Size(21, 20)
        Me.txtComNumber2.TabIndex = 3
        Me.txtComNumber2.Text = "0"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(321, 178)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(54, 13)
        Me.Label11.TabIndex = 25
        Me.Label11.Text = "Increment"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(321, 148)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(29, 13)
        Me.Label12.TabIndex = 24
        Me.Label12.Text = "Stop"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(321, 118)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(29, 13)
        Me.Label13.TabIndex = 23
        Me.Label13.Text = "Start"
        '
        'txtIncrement1
        '
        Me.txtIncrement1.Location = New System.Drawing.Point(212, 175)
        Me.txtIncrement1.Name = "txtIncrement1"
        Me.txtIncrement1.Size = New System.Drawing.Size(100, 20)
        Me.txtIncrement1.TabIndex = 14
        Me.txtIncrement1.Text = "1"
        '
        'txtEndCount1
        '
        Me.txtEndCount1.Location = New System.Drawing.Point(212, 144)
        Me.txtEndCount1.Name = "txtEndCount1"
        Me.txtEndCount1.Size = New System.Drawing.Size(100, 20)
        Me.txtEndCount1.TabIndex = 13
        Me.txtEndCount1.Text = "10"
        '
        'txtStartCount1
        '
        Me.txtStartCount1.Location = New System.Drawing.Point(212, 113)
        Me.txtStartCount1.Name = "txtStartCount1"
        Me.txtStartCount1.Size = New System.Drawing.Size(100, 20)
        Me.txtStartCount1.TabIndex = 12
        Me.txtStartCount1.Text = "1"
        '
        'rdbSerial0_8
        '
        Me.rdbSerial0_8.AutoSize = True
        Me.rdbSerial0_8.Location = New System.Drawing.Point(5, 19)
        Me.rdbSerial0_8.Name = "rdbSerial0_8"
        Me.rdbSerial0_8.Size = New System.Drawing.Size(52, 17)
        Me.rdbSerial0_8.TabIndex = 5
        Me.rdbSerial0_8.TabStop = True
        Me.rdbSerial0_8.Text = "8 port"
        Me.rdbSerial0_8.UseVisualStyleBackColor = True
        '
        'rdbSerial0_16
        '
        Me.rdbSerial0_16.AutoSize = True
        Me.rdbSerial0_16.Location = New System.Drawing.Point(73, 19)
        Me.rdbSerial0_16.Name = "rdbSerial0_16"
        Me.rdbSerial0_16.Size = New System.Drawing.Size(58, 17)
        Me.rdbSerial0_16.TabIndex = 73
        Me.rdbSerial0_16.TabStop = True
        Me.rdbSerial0_16.Text = "16 port"
        Me.rdbSerial0_16.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rdbSerial0_16)
        Me.GroupBox1.Controls.Add(Me.rdbSerial0_8)
        Me.GroupBox1.Location = New System.Drawing.Point(14, 30)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(149, 52)
        Me.GroupBox1.TabIndex = 74
        Me.GroupBox1.TabStop = False
        '
        'lblValue1
        '
        Me.lblValue1.AutoSize = True
        Me.lblValue1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblValue1.Location = New System.Drawing.Point(207, 280)
        Me.lblValue1.Name = "lblValue1"
        Me.lblValue1.Size = New System.Drawing.Size(25, 25)
        Me.lblValue1.TabIndex = 75
        Me.lblValue1.Text = "0"
        '
        'lblValue0
        '
        Me.lblValue0.AutoSize = True
        Me.lblValue0.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblValue0.Location = New System.Drawing.Point(25, 280)
        Me.lblValue0.Name = "lblValue0"
        Me.lblValue0.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.lblValue0.Size = New System.Drawing.Size(25, 25)
        Me.lblValue0.TabIndex = 76
        Me.lblValue0.Text = "0"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.rdbSerial1_16)
        Me.GroupBox2.Controls.Add(Me.rdbSerial1_8)
        Me.GroupBox2.Location = New System.Drawing.Point(198, 28)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(149, 52)
        Me.GroupBox2.TabIndex = 75
        Me.GroupBox2.TabStop = False
        '
        'rdbSerial1_16
        '
        Me.rdbSerial1_16.AutoSize = True
        Me.rdbSerial1_16.Location = New System.Drawing.Point(73, 19)
        Me.rdbSerial1_16.Name = "rdbSerial1_16"
        Me.rdbSerial1_16.Size = New System.Drawing.Size(58, 17)
        Me.rdbSerial1_16.TabIndex = 73
        Me.rdbSerial1_16.TabStop = True
        Me.rdbSerial1_16.Text = "16 port"
        Me.rdbSerial1_16.UseVisualStyleBackColor = True
        '
        'rdbSerial1_8
        '
        Me.rdbSerial1_8.AutoSize = True
        Me.rdbSerial1_8.Location = New System.Drawing.Point(5, 19)
        Me.rdbSerial1_8.Name = "rdbSerial1_8"
        Me.rdbSerial1_8.Size = New System.Drawing.Size(52, 17)
        Me.rdbSerial1_8.TabIndex = 6
        Me.rdbSerial1_8.TabStop = True
        Me.rdbSerial1_8.Text = "8 port"
        Me.rdbSerial1_8.UseVisualStyleBackColor = True
        '
        'btnCloseSave
        '
        Me.btnCloseSave.Location = New System.Drawing.Point(439, 92)
        Me.btnCloseSave.Name = "btnCloseSave"
        Me.btnCloseSave.Size = New System.Drawing.Size(75, 23)
        Me.btnCloseSave.TabIndex = 77
        Me.btnCloseSave.Text = "Save/Close"
        Me.btnCloseSave.UseVisualStyleBackColor = True
        '
        'txtCyclePause
        '
        Me.txtCyclePause.Location = New System.Drawing.Point(212, 206)
        Me.txtCyclePause.Name = "txtCyclePause"
        Me.txtCyclePause.Size = New System.Drawing.Size(100, 20)
        Me.txtCyclePause.TabIndex = 15
        Me.txtCyclePause.Text = "100"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(321, 208)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(51, 13)
        Me.Label3.TabIndex = 79
        Me.Label3.Text = "Off Value"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(586, 12)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(197, 13)
        Me.Label6.TabIndex = 80
        Me.Label6.Text = "Numato Looping Program for two boards"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(586, 31)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(181, 13)
        Me.Label8.TabIndex = 82
        Me.Label8.Text = "On and Off values are in milliseconds"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(586, 69)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(281, 13)
        Me.Label7.TabIndex = 83
        Me.Label7.Text = "Start / Stop values: 8  bits = 0 to 255. 16 bits = 0 to 65535"
        '
        'lblOn0
        '
        Me.lblOn0.AutoSize = True
        Me.lblOn0.Location = New System.Drawing.Point(22, 325)
        Me.lblOn0.Name = "lblOn0"
        Me.lblOn0.Size = New System.Drawing.Size(21, 13)
        Me.lblOn0.TabIndex = 84
        Me.lblOn0.Text = "On"
        '
        'lblOff1
        '
        Me.lblOff1.AutoSize = True
        Me.lblOff1.Location = New System.Drawing.Point(209, 355)
        Me.lblOff1.Name = "lblOff1"
        Me.lblOff1.Size = New System.Drawing.Size(21, 13)
        Me.lblOff1.TabIndex = 85
        Me.lblOff1.Text = "Off"
        '
        'lblOff0
        '
        Me.lblOff0.AutoSize = True
        Me.lblOff0.Location = New System.Drawing.Point(22, 355)
        Me.lblOff0.Name = "lblOff0"
        Me.lblOff0.Size = New System.Drawing.Size(21, 13)
        Me.lblOff0.TabIndex = 86
        Me.lblOff0.Text = "Off"
        '
        'lblOn1
        '
        Me.lblOn1.AutoSize = True
        Me.lblOn1.Location = New System.Drawing.Point(209, 325)
        Me.lblOn1.Name = "lblOn1"
        Me.lblOn1.Size = New System.Drawing.Size(21, 13)
        Me.lblOn1.TabIndex = 87
        Me.lblOn1.Text = "On"
        '
        'lblOffArrow1
        '
        Me.lblOffArrow1.AutoSize = True
        Me.lblOffArrow1.Location = New System.Drawing.Point(267, 355)
        Me.lblOffArrow1.Name = "lblOffArrow1"
        Me.lblOffArrow1.Size = New System.Drawing.Size(16, 13)
        Me.lblOffArrow1.TabIndex = 88
        Me.lblOffArrow1.Text = "<-"
        '
        'lblOnArrow1
        '
        Me.lblOnArrow1.AutoSize = True
        Me.lblOnArrow1.Location = New System.Drawing.Point(267, 325)
        Me.lblOnArrow1.Name = "lblOnArrow1"
        Me.lblOnArrow1.Size = New System.Drawing.Size(16, 13)
        Me.lblOnArrow1.TabIndex = 89
        Me.lblOnArrow1.Text = "<-"
        '
        'lblOffArrow0
        '
        Me.lblOffArrow0.AutoSize = True
        Me.lblOffArrow0.Location = New System.Drawing.Point(80, 355)
        Me.lblOffArrow0.Name = "lblOffArrow0"
        Me.lblOffArrow0.Size = New System.Drawing.Size(16, 13)
        Me.lblOffArrow0.TabIndex = 90
        Me.lblOffArrow0.Text = "<-"
        '
        'lblOnArrow0
        '
        Me.lblOnArrow0.AutoSize = True
        Me.lblOnArrow0.Location = New System.Drawing.Point(80, 325)
        Me.lblOnArrow0.Name = "lblOnArrow0"
        Me.lblOnArrow0.Size = New System.Drawing.Size(16, 13)
        Me.lblOnArrow0.TabIndex = 91
        Me.lblOnArrow0.Text = "<-"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(586, 50)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(206, 13)
        Me.Label9.TabIndex = 92
        Me.Label9.Text = "Maximum value for On/Off: 4,294,967,295"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(586, 92)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(310, 13)
        Me.Label10.TabIndex = 93
        Me.Label10.Text = "Left Port: The Off value is inserted before and after the On value"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(898, 385)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.lblOnArrow0)
        Me.Controls.Add(Me.lblOffArrow0)
        Me.Controls.Add(Me.lblOnArrow1)
        Me.Controls.Add(Me.lblOffArrow1)
        Me.Controls.Add(Me.lblOn1)
        Me.Controls.Add(Me.lblOff0)
        Me.Controls.Add(Me.lblOff1)
        Me.Controls.Add(Me.lblOn0)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtCyclePause)
        Me.Controls.Add(Me.btnCloseSave)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.lblValue0)
        Me.Controls.Add(Me.lblValue1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.lblComPort2)
        Me.Controls.Add(Me.testSerialPort2)
        Me.Controls.Add(Me.txtComNumber2)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.txtIncrement1)
        Me.Controls.Add(Me.txtEndCount1)
        Me.Controls.Add(Me.txtStartCount1)
        Me.Controls.Add(Me.lblComPort1)
        Me.Controls.Add(Me.testSerialPort1)
        Me.Controls.Add(Me.txtComNumber1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtTimeOff0)
        Me.Controls.Add(Me.txtTimeOn0)
        Me.Controls.Add(Me.lblIncrement)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtIncrement0)
        Me.Controls.Add(Me.txtEndCount0)
        Me.Controls.Add(Me.txtStartCount0)
        Me.Controls.Add(Me.startButton1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents startButton1 As Button
    Friend WithEvents txtStartCount0 As TextBox
    Friend WithEvents txtEndCount0 As TextBox
    Friend WithEvents txtIncrement0 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents lblIncrement As Label
    Friend WithEvents txtTimeOn0 As TextBox
    Friend WithEvents txtTimeOff0 As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents SerialPort1 As IO.Ports.SerialPort
    Friend WithEvents txtComNumber1 As TextBox
    Friend WithEvents testSerialPort1 As Button
    Friend WithEvents lblComPort1 As Label
    Friend WithEvents lblComPort2 As Label
    Friend WithEvents testSerialPort2 As Button
    Friend WithEvents txtComNumber2 As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents txtIncrement1 As TextBox
    Friend WithEvents txtEndCount1 As TextBox
    Friend WithEvents txtStartCount1 As TextBox
    Friend WithEvents SerialPort2 As IO.Ports.SerialPort
    Friend WithEvents SerialPort3 As IO.Ports.SerialPort
    Friend WithEvents SerialPort4 As IO.Ports.SerialPort
    Friend WithEvents rdbSerial0_8 As RadioButton
    Friend WithEvents rdbSerial0_16 As RadioButton
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents lblValue1 As Label
    Friend WithEvents lblValue0 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents rdbSerial1_16 As RadioButton
    Friend WithEvents rdbSerial1_8 As RadioButton
    Friend WithEvents btnCloseSave As Button
    Friend WithEvents txtCyclePause As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents lblOn0 As Label
    Friend WithEvents lblOff1 As Label
    Friend WithEvents lblOff0 As Label
    Friend WithEvents lblOn1 As Label
    Friend WithEvents lblOffArrow1 As Label
    Friend WithEvents lblOnArrow1 As Label
    Friend WithEvents lblOffArrow0 As Label
    Friend WithEvents lblOnArrow0 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
End Class
