﻿Imports System
Imports System.IO
Imports System.IO.Ports
Imports System.Xml


Module functions

    '8 Bit: writes the entire string for sending a zero to the numato relay
    Public Function writeZeroFunction8Bit() As String
        Dim writeZero8Bit As String
        writeZero8Bit = "relay writeall 00" + Chr(13) ' this line sends the serial command to the relay module
        Return writeZero8Bit
    End Function

    '8 Bit: writes the entire string for sending to the next value to the numato relay
    Public Function writeOutputSerial8Bit(ByVal serialValue8Bit As String) As String
        Dim writeSerial8Bit = serialValue8Bit
        writeSerial8Bit = "relay writeall " + writeSerial8Bit + Chr(13)
        Return writeSerial8Bit
    End Function

    'Public Function writeToSerial(decimalInput As ulong)

    'End Function

    '8 bit: formats the hex portion of string that is sent to the numato usb relay
    Public Function convertToHex(ByVal DecimalInput As ULong, serialPort8or16bit As ULong) As String ' this function formats the serial hex number that's sent to the relay module. 

        If serialPort8or16bit = 8 Then


            Dim SerialOutputtoReturn As String = 00

            If DecimalInput <= 15 Then
                SerialOutputtoReturn = "0" + Hex(DecimalInput)

            ElseIf DecimalInput >= 16 And DecimalInput <= 255 Then
                SerialOutputtoReturn = Hex(DecimalInput)


            End If
            Return SerialOutputtoReturn.ToLower

        End If


        If serialPort8or16bit = 16 Then

            Dim SerialOutputtoReturn As String = 000

            If DecimalInput <= 15 Then
                SerialOutputtoReturn = "000" + Hex(DecimalInput)

            ElseIf DecimalInput >= 16 And DecimalInput <= 255 Then
                SerialOutputtoReturn = "00" + Hex(DecimalInput)

            ElseIf DecimalInput >= 256 And DecimalInput <= 4095 Then
                SerialOutputtoReturn = "0" + Hex(DecimalInput)

            ElseIf DecimalInput >= 4096 And DecimalInput <= 65535 Then
                SerialOutputtoReturn = Hex(DecimalInput)
            End If

            Return SerialOutputtoReturn.ToLower

        End If

    End Function




    Function ConvertDecimaltoHex16Bit(ByVal DecimalInput As ULong) As String ' this function formats the serial hex number that's sent to the relay module. 


        Dim SerialOutputtoReturn As String = 000

        If DecimalInput <= 15 Then
            SerialOutputtoReturn = "000" + Hex(DecimalInput)

        ElseIf DecimalInput >= 16 And DecimalInput <= 255 Then
            SerialOutputtoReturn = "00" + Hex(DecimalInput)

        ElseIf DecimalInput >= 256 And DecimalInput <= 4095 Then
            SerialOutputtoReturn = "0" + Hex(DecimalInput)

        ElseIf DecimalInput >= 4096 And DecimalInput <= 65535 Then
            SerialOutputtoReturn = Hex(DecimalInput)


        End If

        Return SerialOutputtoReturn


    End Function






End Module
