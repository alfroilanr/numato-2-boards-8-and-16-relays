﻿Imports System.IO.Ports
Public Class clsTimer

    ' THIS CODE ISN'T USED IN THIS PROGRAM

    Function convertToSerial(decimalInput As Integer, bitValue As Integer) As String

        Dim output As String = Nothing ' this will be the value returned

        If bitValue = 8 Then


        End If

        If bitValue = 16 Then


        End If

        Return output

    End Function


    Function millisecondsToPassFunction(timeOn As Integer, timeOff As Integer) As Integer


        'the pin turns on as soon as it enters the loop, so no variable is needed for that

        Dim _timeOff As Date ' this will be the time during the cycle that the pin will go low
        Dim _timeEndCycle As Date ' this is when the cycle ends

        Dim timerFlag As Boolean = 0


        _timeEndCycle = Now.AddMilliseconds(Convert.ToInt32(timeOn) + Convert.ToInt32(timeOff))
        _timeOff = Now.AddMilliseconds(Convert.ToInt32(timeOn))

        While Now < _timeEndCycle

            If Now <= _timeOff Then

                '  writeToSerial(currentCount)
            End If

            If (Now > _timeOff) And (Now < _timeEndCycle) Then

                '        writeToSerial("TurnOff")
            End If


            If Now >= _timeEndCycle Then

            End If

        End While



    End Function

End Class
