﻿

Imports System
Imports System.IO
Imports System.IO.Ports
Imports System.Xml


Public Class Form1


    Dim counter0 As ULong = 0
    Dim counter1 As ULong = 0
    Dim serialState1 As Boolean
    Dim serialState2 As Boolean


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles startButton1.Click


        counter0 = txtStartCount0.Text
        counter1 = txtStartCount1.Text

        Dim hexValue As String

        ' configure com ports
        SerialPort1.PortName = "COM" + txtComNumber1.Text
        SerialPort2.PortName = "COM" + txtComNumber2.Text

        'is the numato a 16 bit or 8 bit unit
        Dim serialPort1Bits As ULong
        Dim serialPort2Bits As ULong

        If rdbSerial0_8.Checked Then
            serialPort1Bits = 8
        ElseIf rdbSerial0_16.Checked Then
            serialPort1Bits = 16
        End If

        If rdbSerial1_8.Checked Then
            serialPort2Bits = 8
        ElseIf rdbSerial1_16.Checked Then
            serialPort2Bits = 16
        End If


        ' check that the 8/16 radiobuttons are checked then sequentially turn on the relays.

        If serialPort2Bits <> 0 And serialPort1Bits <> 0 Then

            'start the outer loop
            Dim counterLoop = Convert.ToInt64(txtStartCount1.Text)

            For aLoop = counterLoop To Convert.ToInt64(txtEndCount1.Text)

                If txtEndCount1.Text < txtStartCount1.Text Then

                    counter1 = txtEndCount1.Text - (counterLoop - txtStartCount1.Text)
                ElseIf txtEndCount1.Text >= txtStartCount1.Text Then
                    counter1 = counterLoop

                End If

                hexValue = convertToHex(counter1, serialPort2Bits)
                SerialPort2.Open()

                SerialPort2.Write("relay writeall " + hexValue + Chr(13))

                ' update the On/Off Arrow and displayed count
                serialState1 = 0
                serialState2 = 1
                updateArrowsAndDisplayedCounters(serialState1, serialState2, counter0, counter1)

                SerialPort2.Close()

                'start the inner loop
                While counter0 <= txtEndCount0.Text


                    SerialPort1.Open()

                    'timeoff0 value goes before and after timon0 value
                    If txtTimeOff0.Text > 0 Then
                        hexValue = convertToHex(0, serialPort1Bits) ' 0 value in hex
                        SerialPort1.Write("relay writeall " + hexValue + Chr(13)) ' write hex value to serialport1

                        ' update the On/Off Arrow and displayed count
                        serialState2 = serialState2
                        serialState1 = 0
                        updateArrowsAndDisplayedCounters(serialState1, serialState2, (counter0 - txtIncrement0.Text), counter1)

                        ' pause for timeoff0 value
                        System.Threading.Thread.Sleep(txtTimeOff0.Text)

                    End If



                    hexValue = convertToHex(counter0, serialPort1Bits) ' setup 0 value in hex

                    SerialPort1.Write("relay writeall " + hexValue + Chr(13)) ' write hex value to serialport1

                    ' update the On/Off Arrow and displayed count
                    serialState2 = serialState2
                    serialState1 = 1
                    updateArrowsAndDisplayedCounters(serialState1, serialState2, counter0, counter1)

                    ' pause for timeon0 value
                    System.Threading.Thread.Sleep(txtTimeOn0.Text)

                    'timeoff0 value goes before and after timon0 value
                    If txtTimeOff0.Text > 0 Then
                        hexValue = convertToHex(0, serialPort1Bits) ' 0 value in hex
                        SerialPort1.Write("relay writeall " + hexValue + Chr(13)) ' write hex value to serialport1
                        ' update the On/Off Arrow and displayed count
                        serialState2 = serialState2
                        serialState1 = 0
                        updateArrowsAndDisplayedCounters(serialState1, serialState2, counter0, counter1)

                        System.Threading.Thread.Sleep(txtTimeOff0.Text) ' pause for timeoff0 value

                    End If

                    SerialPort1.Close()

                    counter0 = counter0 + Convert.ToInt64(txtIncrement0.Text)


                End While

                counterLoop = counterLoop + Convert.ToInt64(txtIncrement1.Text)
                counter0 = txtStartCount0.Text
                hexValue = convertToHex(0, serialPort2Bits)
                SerialPort2.Open()
                SerialPort2.Write("relay writeall " + hexValue + Chr(13))

                ' update the On/Off Arrow and displayed count
                ' update the On/Off Arrow and displayed count
                serialState2 = serialState2
                serialState1 = 0
                updateArrowsAndDisplayedCounters(serialState1, serialState2, counter0, counter1)

                System.Threading.Thread.Sleep(txtCyclePause.Text) ' pause for value at end of serialport2 loop
                SerialPort2.Close()

            Next aLoop

        Else
            MsgBox("Please select 8 or 16 bit on both ports")
        End If


        'TURN OFF EVERYTHING


        hexValue = convertToHex(0, serialPort1Bits)

        SerialPort1.Open()

        SerialPort1.Write("relay writeall " + hexValue + Chr(13))

        SerialPort1.Close()


        hexValue = convertToHex(0, serialPort2Bits)
        SerialPort2.Open()
        ' System.Threading.Thread.Sleep(txtTimeOn0.Text)
        SerialPort2.Write("relay writeall " + hexValue + Chr(13))
        '  System.Threading.Thread.Sleep(txtTimeOff0.Text)


        serialState1 = 0
        serialState2 = 0
        counter0 = 0
        counter1 = 0
        updateArrowsAndDisplayedCounters(serialState1, serialState2, counter0, counter1)


        SerialPort2.Close()


    End Sub


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtComNumber1.Text = My.Settings.serialport1number
        txtComNumber2.Text = My.Settings.serialport2number
        rdbSerial0_8.Checked = My.Settings.rdbSerial0_8
        rdbSerial0_16.Checked = My.Settings.rdbSerial0_16
        rdbSerial1_8.Checked = My.Settings.rdbSerial1_8
        rdbSerial1_16.Checked = My.Settings.rdbSerial1_16
        txtStartCount0.Text = My.Settings.txtStartCount0
        txtEndCount0.Text = My.Settings.txtEndCount0
        txtIncrement0.Text = My.Settings.txtIncrement0
        txtTimeOn0.Text = My.Settings.txtTimeOn0
        txtTimeOff0.Text = My.Settings.txtTimeOff0
        txtStartCount1.Text = My.Settings.txtStartCount1
        txtEndCount1.Text = My.Settings.txtEndCount1
        txtIncrement1.Text = My.Settings.txtIncrement1





    End Sub

    Private Sub testSerialPort1_Click(sender As Object, e As EventArgs) Handles testSerialPort1.Click


        Dim serialPort1Bits As ULong
        Dim serialPort2Bits As ULong

        If rdbSerial0_8.Checked Then
            serialPort1Bits = 8
        ElseIf rdbSerial0_16.Checked Then
            serialPort1Bits = 16

        End If

        If rdbSerial1_8.Checked Then
            serialPort2Bits = 8
        ElseIf rdbSerial1_16.Checked Then
            serialPort2Bits = 16

        End If



        SerialPort1.PortName = "COM" + txtComNumber1.Text
        Try
            SerialPort1.Open()
            MsgBox("Port " + txtComNumber1.Text + " opened successfully")
            SerialPort1.Close()
        Catch ex As Exception
            MsgBox("Port " + txtComNumber1.Text + " failed")
        End Try

    End Sub

    Private Sub testSerialPort2_Click(sender As Object, e As EventArgs) Handles testSerialPort2.Click


        SerialPort2.PortName = "COM" + txtComNumber2.Text
        Try
            SerialPort2.Open()
            MsgBox("Port " + txtComNumber2.Text + " opened successfully")
            SerialPort2.Close()
        Catch ex As Exception
            MsgBox("Port " + txtComNumber2.Text + " failed")
        End Try

    End Sub


    Private Sub btnCloseSave_Click(sender As Object, e As EventArgs) Handles btnCloseSave.Click
        If MsgBox("Are you sure you want to exit?", MsgBoxStyle.OkCancel) = MsgBoxResult.Ok Then
            SerialPort1.Close()
            SerialPort2.Close()
            My.Settings.serialport1number = txtComNumber1.Text
            My.Settings.serialport2number = txtComNumber2.Text
            My.Settings.rdbSerial0_8 = rdbSerial0_8.Checked
            My.Settings.rdbSerial0_16 = rdbSerial0_16.Checked
            My.Settings.rdbSerial1_8 = rdbSerial1_8.Checked
            My.Settings.rdbSerial1_16 = rdbSerial1_16.Checked
            My.Settings.txtStartCount0 = txtStartCount0.Text
            My.Settings.txtEndCount0 = txtEndCount0.Text
            My.Settings.txtIncrement0 = txtIncrement0.Text
            My.Settings.txtTimeOn0 = txtTimeOn0.Text
            My.Settings.txtTimeOff0 = txtTimeOff0.Text
            My.Settings.txtStartCount1 = txtStartCount1.Text
            My.Settings.txtEndCount1 = txtEndCount1.Text
            My.Settings.txtIncrement1 = txtIncrement1.Text




            Application.Exit()

        End If


    End Sub


    Private Sub updateArrowsAndDisplayedCounters(serialstate1 As Boolean, serialstate2 As Boolean, counter0 As Integer, counter1 As Integer
        )


        If serialstate1 = True Then
            lblOnArrow0.Visible = True
            lblOffArrow0.Visible = False
            lblValue0.Text = counter0

        ElseIf serialstate1 = False Then
            lblOnArrow0.Visible = False
            lblOffArrow0.Visible = True
            lblValue0.Text = counter0


        End If


        If serialstate2 = True Then
            lblOnArrow1.Visible = True
            lblOffArrow1.Visible = False
            lblValue1.Text = counter1

        ElseIf serialstate2 = False Then
            lblOnArrow1.Visible = False
            lblOffArrow1.Visible = True
            lblValue1.Text = counter1


        End If
        Application.DoEvents()


    End Sub


End Class




